<!-- No Ic Field -->
<div class="form-group">
    {!! Form::label('no_ic', 'No Ic:') !!}
    <p>{{ $logSemakan2->no_ic }}</p>
</div>

<!-- Ip Field -->
<div class="form-group">
    {!! Form::label('ip', 'Ip:') !!}
    <p>{{ $logSemakan2->ip }}</p>
</div>

