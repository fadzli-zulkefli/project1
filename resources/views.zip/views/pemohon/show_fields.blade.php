<!-- No Ic Field -->
<div class="form-group">
    {!! Form::label('no_ic', 'No Ic:') !!}
    <p>{{ $permohonan->no_ic }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('name', 'Name:') !!}
    <p>{{ $permohonan->name }}</p>
</div>



<!-- negeri Field -->
<div class="form-group">
    {!! Form::label('negeri', 'Negeri:') !!}
    <p>{{ $permohonan->negeri }}</p>
</div>

{{-- 

<!-- No Tel Field -->
<div class="form-group">
    {!! Form::label('no_tel', 'No Tel:') !!}
    <p>{{ $permohonan->no_tel }}</p>
</div>



<!-- Kategori Field -->
<div class="form-group">
    {!! Form::label('kategori', 'Kategori:') !!}
    <p>{{ $permohonan->kategori }}</p>
</div>

<!-- No Akaun Field -->
<div class="form-group">
    {!! Form::label('no_akaun', 'No Akaun:') !!}
    <p>{{ $permohonan->no_akaun }}</p>
</div>

<!-- Nama Bank Field -->
<div class="form-group">
    {!! Form::label('nama_bank', 'Nama Bank:') !!}
    <p>{{ $permohonan->nama_bank }}</p>
</div>

--}}

